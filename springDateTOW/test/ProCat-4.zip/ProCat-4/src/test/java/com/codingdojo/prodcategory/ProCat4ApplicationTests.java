package com.codingdojo.prodcategory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProCat4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
